﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Security;
using System.Threading;
using System.Diagnostics;


namespace App
{
    public partial class Form3 : Form
    {
        private OleDbConnection connection = new OleDbConnection(Properties.Settings.Default.LoginConnectionString);
        Form2 f2 = new Form2();
        public OpenFileDialog openFileDialog2 = new OpenFileDialog();
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "select * from login where Password='" + textBox1.Text + "'";
            OleDbDataReader reader = command.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count = count + 1;
            }
            if (count == 1)
            {
                MessageBox.Show("File opened!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();

                if (openFileDialog2.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        //f2.openFileDialog1 = openFileDialog2;
                        var filePath = openFileDialog2.FileName;
                        using (FileStream fs = File.Open(filePath, FileMode.Open))
                        {
                            Process.Start("notepad.exe", filePath);
                        }
                    }
                    catch (SecurityException ex)
                    {
                        MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                        $"Details:\n\n{ex.StackTrace}");
                    }
                }
                //this.Hide();
            }
            else if (count > 1)
            {
                MessageBox.Show("Duplicate  password");
            }
            else
            {
                MessageBox.Show("Password", "Message Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            connection.Close();
        }
    }
}
