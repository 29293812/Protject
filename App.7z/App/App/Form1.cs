﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace App
{

  
    public partial class Form1 : Form
    {
        private OleDbConnection connection = new OleDbConnection(Properties.Settings.Default.LoginConnectionString);
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "select * from login where Username='" + txtUser.Text + "'and Password='" + txtPass.Text + "'";
            OleDbDataReader reader = command.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count = count + 1;
            }
            if (count == 1)
            {
                MessageBox.Show("Welcome to Word Merge System!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                Form2 f1 = new Form2();
                f1.ShowDialog();
                //this.Hide();
            }
            else if (count > 1)
            {
                MessageBox.Show("Duplicate username and password");
            }
            else
            {
                MessageBox.Show("Invalid Username and/or Password", "Message Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            connection.Close();
            
        }
    }
}
