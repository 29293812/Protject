﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security;
using System.Threading;
using System.Diagnostics;

namespace App
{
    public partial class Form2 : Form
    {
        public OpenFileDialog openFileDialog1 = new OpenFileDialog();

        public Form2()
        {
            InitializeComponent();
           
        }
        
        private void data1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            lblRead1.Visible = true;
            txtRead1.Visible = true;
            btnRead1.Visible = true;


        }

        private void data2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
            lblRead2.Visible = true;
            txtRead2.Visible = true;
            btnRead2.Visible = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRead1_Click(object sender, EventArgs e)
        {

            StreamReader read;

            int[] number = new int[5];
            try
            {
                read = new StreamReader(@"F:\data1.txt");
              
                string[] num = null;
                string inData;
                string tex = txtRead1.Text;// for input of a word to read 
                int count = 0; //initialize word to zero

              
                try
                {
                    while ((inData=read.ReadLine()) !=null)
                    {
                      //  inData = read.ReadLine(); //Split the word using space
                        num = inData.Split(' ');
                     foreach (String word in num)
                        {
                            if (word.Equals(tex))   //Search for the given word
                            {
                                count++;    //If Present increase the count by one
                            }
                        }

                    }
                    if (count != 0)  //Check for count not equal to zero
                    {
                        MessageBox.Show("The given word is present for " + count + " Times in the file");
                        textBox1.AppendText("\n" + tex);
                    }
                    else
                    {
                        MessageBox.Show("The given word is not present in the file");
                    }
                    read.Close();
                }
                catch { }
            }
            catch { }
         }

        private void btnRead2_Click(object sender, EventArgs e)
        {
          
            StreamReader read;

            int[] number = new int[5];
            try
            {
                read = new StreamReader(@"F:\data2.txt");

                string[] num = null;
                string inData;
                string tex = txtRead2.Text;// for input of a word to read 
                int count = 0; //initialize word to zero


                try
                {
                    while ((inData = read.ReadLine()) != null)
                    {
                        //  inData = read.ReadLine(); //Split the word using space
                        num = inData.Split(' ');
                        foreach (String word in num)
                        {
                            if (word.Equals(tex))   //Search for the given word
                            {
                                count++;    //If Present increase the count by one
                            }
                        }

                    }
                    if (count != 0)  //Check for count not equal to zero
                    {
                        MessageBox.Show("The given word is present for " + count + " Times in the file");
                        textBox1.AppendText("\n" + tex);
                    }
                    else
                    {
                        MessageBox.Show("The given word is not present in the file");
                    }
                    read.Close();
                }
                catch { }
            }
            catch { }
        }

        private void btnMerge_Click(object sender, EventArgs e)
        {
          

                string[] file1 = File.ReadAllLines(@"F:\data1.txt");
                string[] file2 = File.ReadAllLines(@"F:\data2.txt");
                string words = "\n"+textBox2.Text+", \n";
                using (StreamWriter writer = File.CreateText(@"F:\data3.txt"))
                {
                    int lineNum = 0;
                    while (lineNum < file1.Length || lineNum < file2.Length)
                    {
                    if (lineNum < file1.Length)
                    {
                        writer.Write(words);
                        writer.WriteLine(file1[lineNum]);
                        writer.Write(",");
                    }
                    if (lineNum < file2.Length)
                    {
                        writer.WriteLine(file2[lineNum]);
                       
                    }
                        lineNum++;
                    }
                }


                MessageBox.Show("Merged data1.txt and data2.txt into data3.txt");

            

        }

        private void openFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.ShowDialog();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {

           
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Form3 v3 = new Form3();
                v3.Show();
               
            }
        }
    }
}

